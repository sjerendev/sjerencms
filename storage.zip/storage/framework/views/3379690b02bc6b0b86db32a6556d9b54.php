<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'actions' => [],
    'heading',
    'subheading' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'actions' => [],
    'heading',
    'subheading' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<header <?php echo e($attributes->class(['fi-header flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between p-4 sm:p-6 filament-sticky'])); ?>>
    <div>
        <h1 class="fi-header-heading text-2xl font-bold tracking-tight">
            <?php echo e($heading); ?>

        </h1>

        <!--[if BLOCK]><![endif]--><?php if($subheading): ?>
            <p class="fi-header-subheading mt-2 text-sm text-gray-500 dark:text-gray-400">
                <?php echo e($subheading); ?>

            </p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <!--[if BLOCK]><![endif]--><?php if(count($actions)): ?>
        <div class="fi-header-actions flex shrink-0 gap-3">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($action); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</header>

<style>
.filament-sticky {
    position: sticky;
    top: 0;
    z-index: 50;
    background-color: rgb(255, 255, 255);
    border-bottom: 1px solid rgb(229, 231, 235);
    margin: 0;
    width: 100%;
    padding: 1rem;
    box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
}

[data-theme='dark'] .filament-sticky {
    background-color: rgb(17, 24, 39);
    border-color: rgb(55, 65, 81);
}
</style>
<?php /**PATH /home/patrik/Code/kalibr/resources/views/filament/pages/header.blade.php ENDPATH**/ ?>